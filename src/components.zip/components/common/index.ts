export { CategoryBadge } from './category-badge';
